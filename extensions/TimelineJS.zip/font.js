var head, style;
head = document.getElementsByTagName('head')[0];

style = document.createElement('style');
style.type = 'text/css';
style.innerHTML = `
    *{font-family:Calibri !important;cursor: url(http://ekladata.com/stwuGLtp-k4Hd-i7W7DxghRX7Fs/Curseur.png), auto !important;}
    h2,p{white-space: pre-wrap !important;}
    .tl-timeline .tl-headline-date, .tl-timeline h3.tl-headline-date{font-family:Calibri !important
    ;}
    .tl-slidenav-next .tl-slidenav-icon:before{content: "\u2192" !important;}
    .tl-slidenav-previous .tl-slidenav-icon:before{content: "\u2190" !important;}
    .tl-icon-image:after{content: "\u2022" !important;}
    .tl-icon-zoom-in:after{content: "\u002B" !important;}
    .tl-icon-zoom-out:after{content: "\u002D" !important;}
    .tl-icon-goback:after{content: "\u2199" !important;}`;
head.appendChild(style);